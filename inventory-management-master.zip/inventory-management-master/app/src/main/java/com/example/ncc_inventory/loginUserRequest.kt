package com.example.ncc_inventory

data class loginUserRequest(val email : String , val password : String)
