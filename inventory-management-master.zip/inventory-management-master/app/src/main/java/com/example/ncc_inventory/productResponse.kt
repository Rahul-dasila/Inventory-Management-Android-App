package com.example.ncc_inventory

data class ProductResponse(val success: Boolean, val message: String) // Replace with your actual response data