package com.example.ncc_inventory

data class deleteOrgreq(val companyId :String)
