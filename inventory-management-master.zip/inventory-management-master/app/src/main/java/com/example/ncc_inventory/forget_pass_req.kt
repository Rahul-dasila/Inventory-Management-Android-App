package com.example.ncc_inventory

data class forget_pass_req(val email: String, val role : String)
