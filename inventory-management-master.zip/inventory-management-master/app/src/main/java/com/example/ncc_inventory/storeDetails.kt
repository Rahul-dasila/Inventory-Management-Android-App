package com.example.ncc_inventory

data class storeDetails(
    val productName:String,
    val productModel: String,
    val productBrand: String
)
