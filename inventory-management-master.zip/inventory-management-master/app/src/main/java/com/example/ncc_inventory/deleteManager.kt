package com.example.ncc_inventory

data class deleteManager(val managerId:String)
