package com.example.ncc_inventory

data class myUser(val userId : String , val userName : String , val designation : String , val section : String , val appointment : String)
