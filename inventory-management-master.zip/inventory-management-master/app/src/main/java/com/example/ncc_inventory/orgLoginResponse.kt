package com.example.ncc_inventory
data class orgLoginResponse(val success : Boolean,val company: company,val token: String? = null)