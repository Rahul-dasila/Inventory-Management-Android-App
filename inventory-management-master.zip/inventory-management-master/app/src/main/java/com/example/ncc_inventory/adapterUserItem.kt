package com.example.ncc_inventory

data class adapterUserItem(val userId : String,
                           val userName : String,
                           val password : String,
                           val designation : String,
                           val section : String,
                           val appointment : String)
