package com.example.ncc_inventory

data class LoginRequest(val email: String, val password: String)