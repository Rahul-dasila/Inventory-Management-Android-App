package com.example.ncc_inventory

data class adapterManagerItem(val id : String ,
                              val name : String ,
                              val password : String,
                              val designation : String,
                              val section : String,
                              val appointment : String,
                              val allProductReport : Boolean,
                              val demandReceived : Boolean,
                              val issueProduct : Boolean)
