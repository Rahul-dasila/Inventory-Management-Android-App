package com.example.ncc_inventory

data class issuedemandresponse(val demands : List<demands>,val success : Boolean)
