package com.example.ncc_inventory

data class User( val userId : String,
                 val email : String,
                 val userName : String,
                 val password : String,
                 val designation : String,
                 val section : String,
                 val appointment : String,
                 val remark : String)
