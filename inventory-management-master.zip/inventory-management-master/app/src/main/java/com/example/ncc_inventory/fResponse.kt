package com.example.ncc_inventory

data class fResponse(val success: Boolean , val filteredProducts: List<filteredProducts>)
