package com.example.ncc_inventory

data class issue_btn_response(val success : Boolean)
