package com.example.ncc_inventory
data class Report(
    val createdAt : String,
    val productId : String,
    val productType : String,
    val productName : String,
    val productModel : String,
    val productBrand : String,
    val status : String
)
