package com.example.ncc_inventory

data class moderators(val moderatorId: String,
                      val moderatorName: String,
                      val password: String,
                      val designation: String,
                      val section: String,
                      val appointment:String)
