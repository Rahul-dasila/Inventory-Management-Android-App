package com.example.ncc_inventory

data class pendingDemandResponse(val demands : List<pendingDemands>, val success : Boolean)
