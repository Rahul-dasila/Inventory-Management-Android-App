package com.example.ncc_inventory

data class demandrequestedResponse(val success: Boolean, val message: String , val demands : List<dmdRequestedItems>)
