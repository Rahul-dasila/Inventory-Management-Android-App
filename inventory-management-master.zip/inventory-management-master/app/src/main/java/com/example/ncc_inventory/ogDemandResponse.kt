package com.example.ncc_inventory

data class ogDemandResponse(val demands: List<pendingDemands> , val success : Boolean)
