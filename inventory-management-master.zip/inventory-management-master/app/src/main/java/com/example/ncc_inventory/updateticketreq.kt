package com.example.ncc_inventory

data class updateticketreq(val ticketId : String , val status: String)
