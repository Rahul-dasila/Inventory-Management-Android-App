package com.example.ncc_inventory

data class moderatorResponse(val success : Boolean , val moderator: moderator,val token: String? = null)
