package com.example.ncc_inventory

data class statusRequestUser(val userId : String)
