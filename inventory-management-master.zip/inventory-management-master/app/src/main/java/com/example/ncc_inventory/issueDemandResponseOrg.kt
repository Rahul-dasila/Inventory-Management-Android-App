package com.example.ncc_inventory

data class issueDemandResponseOrg(val demands : List<orgDEmands>,val success : Boolean)
