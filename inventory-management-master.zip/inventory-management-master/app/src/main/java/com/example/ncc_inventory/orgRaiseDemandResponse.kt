package com.example.ncc_inventory

data class orgRaiseDemandResponse(val success : Boolean)
