package com.example.ncc_inventory

data class filterProductRequest(val productType: String,val productModel : String, val productBrand:String,val quantity : Int)
