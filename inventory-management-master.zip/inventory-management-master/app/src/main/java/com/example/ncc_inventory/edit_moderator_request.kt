package com.example.ncc_inventory

data class edit_moderator_request(val moderatorId : String, val moderatorName : String, val designation : String, val section:  String,val  appointment : String)
