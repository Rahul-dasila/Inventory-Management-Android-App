package com.example.ncc_inventory

data class filteredProducts(
    val productId: String,
    val productType: String,
    val productName: String,
    val productModel: String,
    val productBrand: String
)
