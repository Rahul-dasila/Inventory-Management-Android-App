package com.example.ncc_inventory

data class orgLoginRequest(val email:String, val password : String)
