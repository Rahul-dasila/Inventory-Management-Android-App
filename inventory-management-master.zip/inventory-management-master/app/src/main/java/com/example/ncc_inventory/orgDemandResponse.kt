package com.example.ncc_inventory

data class orgDemandResponse(val success : Boolean, val demands: List<companyDemands>)
