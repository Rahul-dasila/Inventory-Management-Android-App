package com.example.ncc_inventory

data class additra (val success : Boolean)