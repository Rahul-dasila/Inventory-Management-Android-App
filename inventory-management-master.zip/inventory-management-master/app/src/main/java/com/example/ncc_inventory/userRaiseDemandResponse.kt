package com.example.ncc_inventory

data class userRaiseDemandResponse(val success: Boolean, val message: String)
