package com.example.ncc_inventory

import android.provider.ContactsContract.CommonDataKinds.Email

data class moderatorRequest(val email : String, val password : String)
