package com.example.ncc_inventory

data class statusResponseUser(val success: Boolean, val message: String,val data : List<requestStatus>)
