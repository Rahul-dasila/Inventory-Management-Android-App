package com.example.ncc_inventory

data class verifyOtpRes(val success : Boolean)
