package com.example.ncc_inventory

data class ManagerResponse(val success: Boolean, val message: String)