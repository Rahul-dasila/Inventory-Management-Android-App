package com.example.ncc_inventory

data class moderator(val moderatorId : String, val moderatorName : String, val designation : String, val section:  String,val  appointment : String)
