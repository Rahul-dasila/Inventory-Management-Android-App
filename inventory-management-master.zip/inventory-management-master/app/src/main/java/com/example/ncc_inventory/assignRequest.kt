package com.example.ncc_inventory

data class assignRequest(val success : Boolean)
