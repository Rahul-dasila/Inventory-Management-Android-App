package com.example.ncc_inventory

data class orglistRes (val success : Boolean, val companies: List<companies>)