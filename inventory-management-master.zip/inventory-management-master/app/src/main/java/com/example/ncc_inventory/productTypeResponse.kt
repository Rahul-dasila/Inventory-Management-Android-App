package com.example.ncc_inventory

data class productTypeResponse(val productType: String)
