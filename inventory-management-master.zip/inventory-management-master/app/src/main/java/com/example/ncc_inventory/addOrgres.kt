package com.example.ncc_inventory

data class addOrgres(val success : Boolean)
