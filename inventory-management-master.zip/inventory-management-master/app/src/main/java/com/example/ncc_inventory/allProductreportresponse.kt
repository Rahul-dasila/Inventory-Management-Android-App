package com.example.ncc_inventory

data class allProductreportresponse(val success : Boolean , val products: List<products>)
