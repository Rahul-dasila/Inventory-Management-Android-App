package com.example.ncc_inventory

data class receivedUserReq(val userId : String)
