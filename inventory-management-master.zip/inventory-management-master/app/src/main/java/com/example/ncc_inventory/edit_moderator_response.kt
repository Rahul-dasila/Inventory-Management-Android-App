package com.example.ncc_inventory

data class edit_moderator_response(val moderator : moderator,val success : Boolean)
