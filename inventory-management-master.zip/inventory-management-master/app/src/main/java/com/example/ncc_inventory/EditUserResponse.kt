package com.example.ncc_inventory

data class EditUserResponse(val success: Boolean, val message: String)
