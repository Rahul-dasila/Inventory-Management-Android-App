package com.example.ncc_inventory

data class forget_pass_res(val success : Boolean)
