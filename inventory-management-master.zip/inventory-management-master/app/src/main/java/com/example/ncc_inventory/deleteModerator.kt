package com.example.ncc_inventory

data class deleteModerator(val moderatorId: String)
