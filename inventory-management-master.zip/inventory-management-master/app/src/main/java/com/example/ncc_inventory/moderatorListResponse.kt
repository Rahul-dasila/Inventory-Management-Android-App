package com.example.ncc_inventory

data class moderatorListResponse( val moderators: List<moderators>)
