package com.example.ncc_inventory

data class managerDemandAcceptOrrejectResponse(val success : Boolean , val status : String)
