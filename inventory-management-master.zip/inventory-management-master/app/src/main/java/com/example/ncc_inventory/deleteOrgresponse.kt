package com.example.ncc_inventory

data class deleteOrgresponse(val success : Boolean)
