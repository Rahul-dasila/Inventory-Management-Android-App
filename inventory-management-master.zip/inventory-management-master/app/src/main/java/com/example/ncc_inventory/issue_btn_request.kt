package com.example.ncc_inventory

data class issue_btn_request(
    val productId : String,
    val userId : String,
    val demandId :String
)
