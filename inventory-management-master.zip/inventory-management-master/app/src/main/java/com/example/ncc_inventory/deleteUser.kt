package com.example.ncc_inventory

data class deleteUser(val userId : String)
