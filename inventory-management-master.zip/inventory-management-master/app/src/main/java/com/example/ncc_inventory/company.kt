package com.example.ncc_inventory

data class company(
    val companyId: String,
    val companyName : String,
    val email:String,
    val contact_1 : String
)
