package com.example.ncc_inventory

data class receivedUserRes(val success : Boolean,val products : List<formattedDemands>)
