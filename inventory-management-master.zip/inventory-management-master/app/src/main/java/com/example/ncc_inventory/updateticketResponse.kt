package com.example.ncc_inventory

data class updateticketResponse(val success : Boolean)
