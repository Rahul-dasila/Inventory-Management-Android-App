package com.example.ncc_inventory

data class responseAssign(val productId : String , val companyId : String , val demandId : String)
