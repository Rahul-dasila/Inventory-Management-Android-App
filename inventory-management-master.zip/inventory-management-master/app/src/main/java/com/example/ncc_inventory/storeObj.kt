package com.example.ncc_inventory

data class storeObj(val type : String , val name : List<String> , val model : List<String> , val brand : List<String>)
