package com.example.ncc_inventory

data class demandAcptOrRjct(val demandId : String , val status: String)
