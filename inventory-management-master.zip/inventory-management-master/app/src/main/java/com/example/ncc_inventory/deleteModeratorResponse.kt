package com.example.ncc_inventory

data class deleteModeratorResponsee(val success: Boolean, val message: String)
