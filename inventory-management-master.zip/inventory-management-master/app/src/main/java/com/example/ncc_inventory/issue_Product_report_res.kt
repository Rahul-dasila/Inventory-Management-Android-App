package com.example.ncc_inventory

data class issue_Product_report_res(val success : Boolean , val issueList: List<Issued_products>)
