package com.example.ncc_inventory

import android.provider.ContactsContract.CommonDataKinds.Email

data class saveReq(val password : String , val email:String, val role : String)
