package com.example.ncc_inventory
//this file used receives the details of person which is login to app
data class Admin(val profileId: String?, val adminName: String, val email: String, val role: String, val department: String)