package com.example.ncc_inventory

data class editorgRes(val success : Boolean , val company : companies)
