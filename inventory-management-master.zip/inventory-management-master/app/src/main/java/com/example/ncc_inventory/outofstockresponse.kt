package com.example.ncc_inventory

data class outofstockresponse (val outOfStockDemands: List<outOfStockDemands>,val success : Boolean)