package com.example.ncc_inventory

data class UserResponse(val success: Boolean, val message: String)
