package com.example.ncc_inventory

data class verifyOtpReq(val email : String , val otp : Int)
