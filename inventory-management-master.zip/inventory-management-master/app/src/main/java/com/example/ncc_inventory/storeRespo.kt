package com.example.ncc_inventory

data class storeRespo(
    val productType: String,
    val details: List<storeDetails>
)
