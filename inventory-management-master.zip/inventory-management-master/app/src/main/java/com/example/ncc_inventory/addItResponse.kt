package com.example.ncc_inventory

data class addItResponse(val moderatorId : String, val email : String,val moderatorName : String, val password : String, val designation : String, val section : String,val appointment : String,val remark : String)
