package com.example.ncc_inventory

data class raiseReq(val ticketId : String, val issueType : String ,val  message : String, val issuedBy : String,val productId : String)
