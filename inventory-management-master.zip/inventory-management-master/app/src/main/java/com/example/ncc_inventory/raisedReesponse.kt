package com.example.ncc_inventory

data class raisedReesponse(val tickets: List<tickets>, val success : Boolean)
